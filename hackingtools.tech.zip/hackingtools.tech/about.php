<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>About Us</title>
    <meta name="description" content="Hacking tools | free hacking software | keyloogers">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 <!-- add icon link -->
        <link rel = "icon" href =  
"img/hacking-tools-logo.png" 
        type = "image/x-icon">
        <style>
        marquee
        {
        color:red;
        }
        
        </style>
        <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
    async defer>
    
</script>
<script src='https://www.google.com/recaptcha/api.js'></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="Sahil Mulla | Computer Engineer | Sahil | Sahil J Mulla | Sahil Jakirhusen Mulla | Sahil Mulla MMIT">

<script src="https://www.google.com/recaptcha/api.js?render=_reCAPTCHA_site_key"></script>
<script>
grecaptcha.ready(function() {
    grecaptcha.execute('_reCAPTCHA_site_key_', {action: 'homepage'}).then(function(token) {
       ...
    });
});
</script>

        <style type="text/css">
  



  *{


    margin: 0;
    padding: 0;
    font-family: 'Josefin Sans', sans-serif;
  }
</style>
    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/gijgo.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

    <!-- header-start -->
  <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container-fluid p-0">
                    <div class="row align-items-center no-gutters">
                        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2">
                            <div class="">
                                <a href="index.php">
                                    
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-8">
                            <div class="main-menu  d-none d-lg-block d-md-block d-sm-block text-center">
                                <nav>
                                    <ul id="navigation">
                                        <li><a class="active" href="index.php">home</a></li>
                                       
                                        <li><a href="hacking-tools.php">Hacking Tools</a></li>
                                         <li><a href="term.html">Terms & Condition</a></li>
                                        <li><a href="#">pages <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                               
                                                <li><a href="about.php">about</a></li>
                                                <li><a href="privacy.html">Privacy & Policy</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-lg-2 d-none d-lg-block col-md-2">
                        </div>
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none d-md-none "></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->

    <!-- slider_area_start -->
    
    <!-- slider_area_end -->

  <div class="about_area">
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-lg-5 offset-lg-1">
                    <div class="about_info">
                        <div class="section_title white_text">
                            <span class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">About Us</span>
                            <h3 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".4s">HackingTools.tech </h3>
                            <p class="mid_text wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                            Welcome to hackingtools.tech, your number one source for all things Related to hacking tools. We're dedicated to providing you the very best of Tools, with an emphasis on Good Quality Tools, Exact Information, Effective Product. </p>

                            <p class="mid_text wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                            Founded in 2020 by Sahil Mulla, hackingtools.tech has come a long way from its beginnings in Pune. When Sahil first started out, his passion for hackingtools drove them to start their own business.
                            </p>
                            <p class="mid_text wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                            We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.
                            </p>
                            <p class="mid_text wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                            Sincerely,
                            </p> 
                            <p class="mid_text wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                            Sahil Mulla
                            </p>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <!-- team_member_start -->
    
    <!--/ team_member_end -->

    <!-- testimonial_area  -->
   
    <!-- /testimonial_area  -->

    <div class="get_in_tauch_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section_title text-center mb-90">
                        <h3 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">Get in Touch</h3>
                        <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".4s">Tour function information without cross action media value quickly maximize timely deliverables.</p>
                    </div>
                </div>
            </div>
         <div class="row justify-content-center">
                <div class="col-lg-8">
                <h5 class='text-centre text-success'><?= $result; ?> </h5>
                    <div class="touch_form">
                        <form action="" method="post" >
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="single_input wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
                                        <input type="text" placeholder="Your Name" name='name' required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="single_input wow fadeInUp" data-wow-duration="1s" data-wow-delay=".4s">
                                        <input type="email" placeholder="Email" name='email' required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="single_input wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                                        <input type="text" placeholder="Subject" name='subject' required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="single_input wow fadeInUp" data-wow-duration="1s" data-wow-delay=".6s">
                                       <textarea name="msg" id="" cols="30" placeholder="Message" rows="10"  required></textarea>
                                    </div>
                                </div>
                                <div class="g-recaptcha" data-sitekey="6Ld5mfgUAAAAAMLangY9aXuRP6_8_q9hvXE0bOjH" style="margin:10px 20px;"></div>
      <br/>

                                <div class="col-lg-12">
                                    <div class="submit_btn wow fadeInUp" data-wow-duration="1s" data-wow-delay=".7s">
                                        <button class="boxed-btn3" type="submit" name='submit' >Send Message</button>
                                    </div>
                                </div>
                            </div>
                            
                            
                            
                            
                            
                            <div style="font-size: 15px; color:green; padding:30px;" class="col-md-8">
            <?Php
            if(isset($_POST['submit']))
            {
                $user_name = $_POST['name'];
                $subject = $_POST['subject'];
                $user_email = $_POST['email'];
                $user_message= $_POST['msg'];

                $email_from = 'info@hackingtools.tech';
                $email_subject = "Form Submission: $subject \n";
                $email_body = "Name :  $user_name. \n ".
                              "Subject : $subject \n ".
                              "Email Id : $user_email \n".
                              "Message : $user_message \n".
                              "Thank You";

                $to_email = "sahilmulla199@gmail.com";
                $headers = "From :$email_from \r \n ";
                $headers  = "Replay-To :$user_email \r \n ";

                $secretKey = "6Ld5mfgUAAAAAHmXMd-xYepzwUNAwjMBkadUkD5v";
                $responseKey =$_POST['g-recaptcha-response'];
                $UserIP = $_SERVER['REOMTE_ADDR'];
                $url ="https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$responseKey&remoteip=$UserIP";

                //$response = file_get_contents($url);
                
                //$response = json_decode( $response);

                if(mail($to_email, $email_subject, $email_body,$headers))
                {
                //$response->success
                               
                      
                    echo "Message Sent Successfully";

                }
                else
                {
              
                     echo "<marquee>Invalid Captcha, Please Try Again... </marquee>";
                }
                
                $to = $_POST['email'];
                $email_subject1 = "Message From Hackingtools.tech \n";
                $headers1  = "Thank you $user_name for contacting us  \r \n ";
                $email_body1 = "We appreciate that you’ve taken the time to write us. We’ll get back to you very soon. Please come back and see us often. \n \n Sahil Mulla \n  (hackingtools.tech)";


                mail($to,$email_subject1, $email_body1,$headers1);


            } 
            ?>
            
            
            </div>
            </form>
          









                            
                            
                            
                            
                            
                            
                            
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- footer start -->
   <footer class="footer">
        <div class="footer_top">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-2 col-md-3">
                        <div class="footer_logo wow fadeInRight" data-wow-duration="1s" data-wow-delay=".3s">
                            <a href="index.html">
                                <img src="img/logo.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-md-9">
                        <div class="menu_links">
                            <ul>
                                <li><a class="wow fadeInDown" data-wow-duration="1s" data-wow-delay=".2s" href="about.html">About</a class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s"></li>
                                <li><a class="wow fadeInDown" data-wow-duration="1s" data-wow-delay=".4s" href="service.html">Term & Condition</a></li><li><a class="wow fadeInDown" data-wow-duration="1s" data-wow-delay=".4s" href="elements.html">Privacy & Policy</a></li>

                               
                                <li><a class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.1s" href="contact.html">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <div class="socail_links">
                            <ul>
                                <li><a class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s" href="https://www.facebook.com/sahil.mulla.306"> <i class="fa fa-facebook"></i> </a></li>
                                <li><a class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".4s" href="https://twitter.com/SahilMu64171390"> <i class="fa fa-twitter"></i> </a></li>
                                <li><a class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" href="https://www.instagram.com/sahilm9620/"> <i class="fa fa-instagram"></i> </a></li>
                                </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right_text">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.3s">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This  is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/ footer end  -->

    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/gijgo.min.js"></script>

    <!--contact js-->
    <script src="js/contact.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/mail-script.js"></script>

    <script src="js/main.js"></script>
</body>

</html>