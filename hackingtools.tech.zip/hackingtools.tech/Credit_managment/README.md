<html>
  <head>
    <title>credit managment</title>
    </head>
    
    <body>
    
    <h1> 
    credit management Application</h1>
    
    <a href="/index.php">open </a>
    
    
    
    
    </body> 
  
  </html>
