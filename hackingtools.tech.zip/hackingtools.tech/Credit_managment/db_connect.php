<?php
	
//make connection with database
	
$link = mysqli_connect("fdb22.awardspace.net","3382823_credit","sahilmulla199",'3382823_credit');

// Check connection

if($link === false) 
{

    	die("ERROR: Could not connect. " . mysqli_connect_error());
	
}


?>